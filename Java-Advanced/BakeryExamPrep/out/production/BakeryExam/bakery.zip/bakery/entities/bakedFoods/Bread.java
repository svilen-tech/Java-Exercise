package bakery.entities.bakedFoods;

public class Bread extends BaseFood{
    public Bread(String name, double price) {
        super(name, 200, price);
    }
}
