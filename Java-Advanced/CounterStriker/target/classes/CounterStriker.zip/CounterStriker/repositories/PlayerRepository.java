package CounterStriker.repositories;

import CounterStriker.models.guns.Gun;
import CounterStriker.models.players.Player;
import CounterStriker.models.players.PlayerImpl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class PlayerRepository implements Repository<Player> {
    private List<Player> models;

    public PlayerRepository(){
        models = new ArrayList<>();
    }

    @Override
    public List<Player> getModels() {
        return this.models;

    }

    @Override
    public void add(Player model) {
        if (model == null) {
            throw new NullPointerException("Cannot add null in Player Repository");
        }
        models.add(model);


    }

    @Override
    public boolean remove(Player model) {
        return models.remove(model);

    }

    @Override
    public Player findByName(String name) {
        for (Player player : models) {
            if (player.getUsername().equals("name")) {
                return player;
            }
        }
        return null;
    }
}
